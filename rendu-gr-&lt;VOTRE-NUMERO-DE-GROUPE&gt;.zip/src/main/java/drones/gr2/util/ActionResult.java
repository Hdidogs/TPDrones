package drones.gr2.util;

public abstract class ActionResult {
}
