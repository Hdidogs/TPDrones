package drones.gr2.util.drone;

public abstract class MoveResult {


}
