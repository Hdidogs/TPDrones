package drones.gr2.util.drone;

public class Rejected extends MoveResult {

}
