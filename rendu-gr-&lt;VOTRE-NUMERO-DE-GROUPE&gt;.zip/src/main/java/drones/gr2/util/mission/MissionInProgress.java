package drones.gr2.util.mission;

public class MissionInProgress extends MissionStatut {
    @Override
    public String toString() {
        return "In Progess";
    }
}
