package drones.gr2.util.mission;

public class CannotProceed extends MissionStatut {
    @Override
    public String toString() {
        return "Can not proceed";
    }
}
