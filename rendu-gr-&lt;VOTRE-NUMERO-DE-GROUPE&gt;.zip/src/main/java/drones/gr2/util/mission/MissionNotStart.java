package drones.gr2.util.mission;

public class MissionNotStart extends MissionStatut {
    @Override
    public String toString() {
        return "Not start";
    }
}
