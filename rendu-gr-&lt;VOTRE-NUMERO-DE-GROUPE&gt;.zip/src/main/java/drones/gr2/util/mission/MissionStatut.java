package drones.gr2.util.mission;

public abstract class MissionStatut {
}
