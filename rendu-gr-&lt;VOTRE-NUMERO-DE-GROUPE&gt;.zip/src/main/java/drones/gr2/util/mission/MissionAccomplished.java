package drones.gr2.util.mission;

public class MissionAccomplished extends MissionStatut {
    @Override
    public String toString() {
        return "Accomplished";
    }
}
