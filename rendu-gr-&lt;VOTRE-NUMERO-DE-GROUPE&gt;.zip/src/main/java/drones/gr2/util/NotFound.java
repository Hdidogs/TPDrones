package drones.gr2.util;

public class NotFound extends ActionResult{
}
