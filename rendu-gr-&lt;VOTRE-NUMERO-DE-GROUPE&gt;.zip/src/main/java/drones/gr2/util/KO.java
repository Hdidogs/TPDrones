package drones.gr2.util;

public class KO extends ActionResult {
}
