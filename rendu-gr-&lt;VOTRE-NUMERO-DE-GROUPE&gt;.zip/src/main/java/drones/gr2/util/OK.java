package drones.gr2.util;

public class OK extends ActionResult {
}
