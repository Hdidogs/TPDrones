package drones.gr2.util;

public class Found extends ActionResult{
}
