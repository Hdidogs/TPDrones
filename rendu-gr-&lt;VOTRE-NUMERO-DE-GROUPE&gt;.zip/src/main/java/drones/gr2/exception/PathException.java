package drones.gr2.exception;

public class PathException extends RuntimeException {

    public PathException(String message) {
        super(message);
    }
}
