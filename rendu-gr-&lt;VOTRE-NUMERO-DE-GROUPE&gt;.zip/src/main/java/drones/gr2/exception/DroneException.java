package drones.gr2.exception;

public class DroneException extends RuntimeException {
    public DroneException(String message) {
        super(message);
    }

}
